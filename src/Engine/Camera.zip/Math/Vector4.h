#pragma once
struct Vector4
{
    float x;
    float y;
    float z;
    float w;
};