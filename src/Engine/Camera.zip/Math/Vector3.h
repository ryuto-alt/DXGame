#pragma once
struct Vector3
{
    float x;
    float y;
    float z;
};