#pragma once

class D3DResourceLeakChecker
{
public:
	~D3DResourceLeakChecker();
};